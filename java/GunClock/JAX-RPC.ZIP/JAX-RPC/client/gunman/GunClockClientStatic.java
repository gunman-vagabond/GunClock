package gunman;
import  staticstub.*;

import javax.xml.rpc.Stub;

public class GunClockClientStatic {

    private static String endpointAddress = "http://localhost:8080/GunClock-jaxrpc/GunClockWebService";
    private static int clockSize = 20;

    public static void main(String[] args) {

        if(args.length >= 1){ endpointAddress=args[0]; }
        if(args.length >= 2){ clockSize = Integer.parseInt(args[1]); }

        System.out.println("Endpoint address = " + endpointAddress);

        try {
            Stub stub = (Stub) (new GunClockService_Impl().getGunClockIFPort());
            stub._setProperty(javax.xml.rpc.Stub.ENDPOINT_ADDRESS_PROPERTY,
                              endpointAddress); 
            GunClockIF gunClock = (GunClockIF)stub;

            gunClock.setClockSize(clockSize);
            System.out.println(gunClock.getGunClock());

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }    
} 

