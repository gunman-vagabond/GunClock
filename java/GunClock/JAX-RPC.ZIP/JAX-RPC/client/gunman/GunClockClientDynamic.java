package gunman;

import java.net.URL;
import javax.xml.rpc.Service;
import javax.xml.rpc.JAXRPCException;
import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceFactory;
import staticstub.GunClockIF;

public class GunClockClientDynamic {

    private static int clockSize = 15;

    public static void main(String[] args) {
        try {

            String UrlString = args[0] + "?WSDL";
            String nameSpaceUri = "urn:GunClockTarget";
            String serviceName = "GunClockService";
            String portName = "GunClockIFPort";

            System.out.println("UrlString = " + UrlString);
            URL gunClockWsdlUrl = new URL(UrlString);
            
            ServiceFactory serviceFactory =
                ServiceFactory.newInstance();
            
            Service gunClockService =
                serviceFactory.createService(gunClockWsdlUrl, 
                new QName(nameSpaceUri, serviceName));
            
            GunClockIF myProxy = 
                (GunClockIF) 
                gunClockService.getPort(
                new QName(nameSpaceUri, portName), 
                GunClockIF.class); 

            myProxy.setClockSize(clockSize);
            System.out.println(myProxy.getGunClock());

        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    } 
}  

