package gunman;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GunClockIF extends Remote {
	public String getGunClock() throws RemoteException;
	public void setClockSize(int clockSize) throws RemoteException;
}
