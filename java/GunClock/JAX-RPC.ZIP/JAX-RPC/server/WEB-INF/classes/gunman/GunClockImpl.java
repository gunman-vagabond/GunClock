package gunman;

public class GunClockImpl implements GunClockIF {

	private int clockSize = 20;

	public String getGunClock(){

		GunClockBean gunClockBean = new GunClockBean();
		gunClockBean.setClockSize(this.clockSize);

		return gunClockBean.getGunClock();
	}

	public void setClockSize(int clockSize){

		this.clockSize = clockSize;

	}
}
