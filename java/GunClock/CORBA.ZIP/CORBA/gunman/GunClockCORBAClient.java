package gunman;

import gunman.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;

public class GunClockCORBAClient {

	static GunClockCORBA gunClockCORBAImpl;

	public static void main(String args[]) {
		try{

			// ORB$B$N@8@.$H=i4|2=(B
			ORB orb = ORB.init(args, null);

			// $B%M!<%`%5!<%S%9$X$N;2>H$r<hF@(B
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

			// $B%M!<%`%5!<%S%9$+$i(B GunClockCORBA $B$H$$$&L>A0$N%5!<%P%s%H$r8!:w$7!"(B
			// $B;2>H$r<hF@$9$k(B
			String name = "GunClockCORBA";
			gunClockCORBAImpl = GunClockCORBAHelper.narrow(ncRef.resolve_str(name));

			// $B%5!<%P%*%V%8%'%/%H$N%a%=%C%I$r8F$S=P$9!#(B
			int gunClockSize=20;
			System.out.println(gunClockCORBAImpl.getGunClock(gunClockSize));

		} catch (Exception e) {
			System.out.println("ERROR : " + e) ;
			e.printStackTrace(System.out);
		}
	}
}

