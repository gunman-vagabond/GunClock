package gunman;
import gunman.*;

public class GunClockCORBAImpl extends GunClockCORBAPOA {

	public String getGunClock(int size){
		GunClockBean gunClockBean = new GunClockBean();
		gunClockBean.setClockSize(size);
		return gunClockBean.getGunClock();
	}

}
